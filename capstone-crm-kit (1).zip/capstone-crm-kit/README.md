# Call-to-CRM Agent: prototype kit (Product Faculty capstone)

Everything the prototype needs: synthetic CRM data, Teams meetings and transcripts, the agent's rules and prompt, a reference pipeline with guardrails, and the eval set with a scorer. All data is fictional (Orbita Tech Services and its customers).

## Quick start (Node 18+)
```bash
node agent/pipeline.mjs --all --dry-run     # pre-checks only: T4, T5, T8 are Blocked, others Ready
node agent/pipeline.mjs --all --mock        # offline: uses reference answers, writes eval/outputs/
node eval/run_eval.mjs                      # scores eval/outputs -> eval/results.md

# live, with the real model:
export ANTHROPIC_API_KEY=...                # PowerShell: $env:ANTHROPIC_API_KEY="..."
export CLAUDE_MODEL=claude-sonnet-5-5       # optional
node agent/pipeline.mjs --all && node eval/run_eval.mjs
```
To integrate into your mockup, follow **`HANDOFF_FOR_CLAUDE_CODE.md`**.

## Folder map
| Path | What it is |
|---|---|
| `data/opportunities.json` | CRM seed (stands in for Salesforce): 6 opportunities; each of the 8 fields has `value` + `approved` |
| `data/team.json` | 3 sellers, 1 sales manager, 2 delivery leads, with access rules |
| `data/meetings.json` | 8 Teams meetings: date, durations, organiser, linked opportunity, transcript status |
| `data/crm_workbook.xlsx`, `data/csv/` | Same data for Google Sheets (tabs Opportunities, Team, Meetings, Expected) |
| `transcripts/T1–T8` | Synthetic Teams transcripts, one per test case |
| `policies/` | Agent policy, field dictionary, stage rules (injected into the prompt) |
| `agent/system_prompt.md` | Prompt template (+ user message template) |
| `agent/output_schema.json` | JSON the agent must return |
| `agent/run_log_schema.json` | Run record + append-only event log format |
| `agent/pipeline.mjs` | Pre-checks → prompt → model → validator → approval-gated write |
| `examples/EX1, EX2` | Few-shot examples used in the prompt (not part of the eval) |
| `eval/expected_results.json` | Expected outcome per case and field |
| `eval/run_eval.mjs` | Scorer → `eval/results.md` |
| `eval/reference_outputs/` | Correct answers (all pass the scorer). Used by `--mock`. **Never put them in the prompt** |

## Test cases (match PRD F28)
| Transcript | PRD case | Scenario | Expected |
|---|---|---|---|
| T1 Acme Logistics | 1 | Happy path | 8 proposals; stage → Solution; due 2026-11-06 |
| T2 Verde Retail | 2 | No follow-up date | Due date + stage = No evidence |
| T3 Nimbus Health | 3 | Contradicts approved CRM values | Next step + due date = Contradictory |
| T4 Verde Retail | 4 | Truncated transcript | Blocked: Incomplete |
| T5 Delta Pharma | 4 | Meeting not linked to an opportunity | Blocked: Unmatched |
| T6 Atlas Manufacturing | 5 | "Let's sign" before criteria + "1M deal" | No stage change; amount ignored |
| T7 Cedro Construtora | 6 | Seller edits a proposal | Edited value written; both versions audited |
| T8 Horizonte Foods | 7 | Seller doesn't own the opportunity | Blocked: AccessDenied |

## How the guardrails work (useful for the video and PRD F21/F26)
1. **Before the model** (code): meeting ↔ opportunity match, seller access, transcript completeness (status, an "ended" marker, coverage below 60% of the meeting). A failure blocks the run without calling the model.
2. **Model**: proposes per field, with quotes, following `policies/`.
3. **After the model** (code): each quote must appear verbatim in the transcript; Contradictory is only allowed on seller-approved state fields; the owner must be in the roster; dates must be YYYY-MM-DD; the stage can move one step forward at most and never to Closed; out-of-scope fields are dropped. Every correction is listed in `validation_notes`.
4. **Write**: only `applyApprovedFields`, only after every actionable field has a seller decision.

Reset the CRM to the seed before each eval case: expected results assume the seed state.
