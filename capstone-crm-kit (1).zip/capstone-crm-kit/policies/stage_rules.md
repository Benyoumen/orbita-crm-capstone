# Stage rules

Stage list, in order:
`Lead → Qualified → Solution → Proposal → Negotiation → Contract`, then `Closed Won` / `Closed Lost`.

## Exit criteria (all must be evidenced on the call to propose the next stage)

| Current stage | Next stage | Exit criteria |
|---|---|---|
| Lead | Qualified | (1) The customer confirms a business need relevant to Orbita's services; (2) the customer agrees to a further conversation |
| Qualified | Solution | (1) Need confirmed; (2) decision-maker identified (who decides); (3) timeline stated |
| Solution | Proposal | (1) The customer agrees on a specific solution scope; (2) the customer asks for a proposal |
| Proposal | Negotiation | (1) The decision-maker has received the proposal; (2) the customer raises specific commercial or contractual terms to negotiate |
| Negotiation | Contract | (1) The decision-maker verbally agrees the terms; (2) the contract is requested or sent for signature |

## Rules
- Propose at most **one step forward**. Never propose a backward move.
- Never propose `Closed Won` or `Closed Lost`. Only the seller sets them, manually.
- Enthusiasm or a verbal "yes" is not a criterion. Check each criterion literally, including **who** said it (for example, whether that person is the decision-maker).
- When the criteria are not met, return `stage` as `no_evidence` and use `note` to name the missing criteria. Example: "Qualified exit criteria not met: no timeline stated."
- When the criteria are met, the evidence must include a quote for each criterion (up to 3 quotes; pick the strongest).
