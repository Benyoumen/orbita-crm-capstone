# Field dictionary: the eight in-scope fields

**Per-call fields** describe this call only: `call_summary`, `objection`, `commitment`. Proposing a new value for them is normal; earlier values remain in the run history.
**State fields** describe the opportunity now: `customer_need`, `next_step`, `follow_up_owner`, `follow_up_due_date`, `stage`. Only these can be `contradictory` (see agent_policy.md).

| Field | Type | Definition | Evidence rule | Format |
|---|---|---|---|---|
| `call_summary` | per-call | What the call was about, the key facts, and the outcome | Only facts stated in the transcript | 2–4 sentences, 80 words max |
| `customer_need` | state | The business problem the customer wants solved, in their terms | Stated by the customer, or the seller's restatement confirmed by the customer | 40 words max |
| `objection` | per-call | Concerns, risks, or blockers raised by the customer on this call | A customer statement. Never the seller's speculation | 40 words max; several objections separated by `; ` |
| `commitment` | per-call | Explicit promises made by either side | An explicit "I will / we will". Intentions such as "maybe" or "we'll see" don't count | `Party (person): action (by date)`; several separated by `; ` |
| `next_step` | state | The agreed next action or meeting that moves the opportunity forward | Agreed by both sides: proposed by one side and accepted by the other. A step the customer declined is not a next step | 40 words max |
| `follow_up_owner` | state | Internal person responsible for the next follow-up | That person says they will do it, or is explicitly assigned. Must be in the team roster; customer-side people are not allowed | Full name exactly as in the roster |
| `follow_up_due_date` | state | Date by which the follow-up owner must act | An explicit date or a day ("by Friday"). Resolve relative days from the meeting date. "No rush", "soon", or no timeframe → `no_evidence` | `YYYY-MM-DD` |
| `stage` | state | Sales stage of the opportunity | See stage_rules.md. Propose only when the exit criteria of the current stage are evidenced on this call | One value of the stage list |

## Good and bad examples
(These use the Mar Azul Hotels example from `examples/EX1`, not the eval transcripts.)

**call_summary**
- Good: "Intro call with the Revenue Director. Room rates are set manually in spreadsheets and revenue is lost on high-demand weekends. He wants a demand forecast per hotel but has a three-person team. Working session agreed for 15 Oct."
- Bad: "Great call, customer is very interested and will probably buy." (opinion, not facts)

**customer_need**
- Good: "Demand forecast for each hotel to adjust room rates in advance"
- Bad: "Interested in our services" (not a need)

**objection**
- Good: "Revenue team is only three people; cannot take on a heavy implementation"
- Bad: "Price may be an issue" (when price was never mentioned)

**commitment**
- Good: "Orbita (Ana): send working-session agenda by 9 Oct"
- Bad: "Customer will think about it"

**next_step**
- Good: "Working session with the Mar Azul revenue team on 15 Oct at 10:00"
- Bad: "Second meeting with the team" (when the customer said "not yet")

**follow_up_owner**
- Good: "Ana Ribeiro"
- Bad: "Gustavo Teixeira" (customer side) or "Ana" (not the full roster name)

**follow_up_due_date**
- Good: meeting on Tue 2026-10-06, "by Friday" → `2026-10-09`
- Bad: inventing a date when the customer said "no rush"
