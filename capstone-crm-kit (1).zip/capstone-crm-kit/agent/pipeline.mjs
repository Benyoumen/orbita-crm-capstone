// Call-to-CRM Agent: reference pipeline (Node 18+, no dependencies).
//
//   node agent/pipeline.mjs --case T1           run one eval case (needs ANTHROPIC_API_KEY)
//   node agent/pipeline.mjs --all               run all eval cases -> eval/outputs/*.json
//   node agent/pipeline.mjs --all --dry-run     no API call: pre-checks + prompt preview only
//   node agent/pipeline.mjs --all --mock        no API call: returns eval/reference_outputs (build/demo the UI offline)
//   node agent/pipeline.mjs --meeting MTG-1001 --user U01   app-style run on a meeting's linked opportunity
//
// Env: ANTHROPIC_API_KEY, CLAUDE_MODEL (default below).
// The app can import { prepareRun, buildPrompt, callModel, validateOutput, applyApprovedFields } instead of using the CLI.

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const KIT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const rd = (p) => fs.readFileSync(path.join(KIT, p), "utf8");
const rj = (p) => JSON.parse(rd(p));

export const FIELDS = ["call_summary", "customer_need", "objection", "commitment",
  "next_step", "follow_up_owner", "follow_up_due_date", "stage"];
export const STATE_FIELDS = ["customer_need", "next_step", "follow_up_owner", "follow_up_due_date", "stage"];
export const STAGES = ["Lead", "Qualified", "Solution", "Proposal", "Negotiation", "Contract", "Closed Won", "Closed Lost"];
const DEFAULT_MODEL = process.env.CLAUDE_MODEL || "claude-sonnet-5-5";

// ------------------------------------------------------------------ data access (swap for your CRM store)
export function loadData(crmOverride) {
  return {
    team: rj("data/team.json"),
    meetings: rj("data/meetings.json"),
    opportunities: crmOverride || rj("data/opportunities.json"),
  };
}

// ------------------------------------------------------------------ log helper
export function newLog(runId) {
  const events = [];
  return {
    events,
    add(actor, action, object_id, outcome, detail = "") {
      events.push({ run_id: runId, seq: events.length + 1, timestamp: new Date().toISOString(), actor, action, object_id, outcome, detail });
    },
  };
}

const tsToSec = (t) => { const [h, m, s] = t.split(":").map(Number); return h * 3600 + m * 60 + s; };
const blocked = (meeting_id, opportunity_id, source_status, block_reason) =>
  ({ meeting_id, opportunity_id, source_status, run_status: "Blocked", block_reason, fields: [], ignored_out_of_scope: [], validation_notes: [] });

// ------------------------------------------------------------------ 1. deterministic pre-checks (no LLM)
// Order: meeting exists -> opportunity match -> seller access -> transcript usable.
export function prepareRun({ meetingId, opportunityId, userId, data, log }) {
  const meeting = data.meetings.find((m) => m.meeting_id === meetingId);
  log.add("system", "run_created", meetingId, "ok", `user=${userId}`);
  if (!meeting) return { output: blocked(meetingId, opportunityId ?? null, "Missing", "Teams meeting not found.") };

  const oppId = opportunityId === undefined ? meeting.linked_opportunity_id : opportunityId;
  if (!meeting.linked_opportunity_id || !oppId || meeting.linked_opportunity_id !== oppId) {
    log.add("system", "run_blocked", meetingId, "blocked", "meeting not linked to exactly this opportunity");
    return { output: blocked(meetingId, oppId ?? null, "Unmatched",
      "This Teams meeting is not linked to a Salesforce opportunity. Link it in the CRM or update the record manually.") };
  }

  const opp = data.opportunities.find((o) => o.opportunity_id === oppId);
  const user = data.team.find((u) => u.user_id === userId);
  const hasAccess = !!opp && !!user && (user.access === "all_opportunities_read" || (user.access === "own_opportunities" && opp.owner_id === userId));
  log.add("system", "access_checked", oppId, hasAccess ? "ok" : "blocked", `user=${userId}`);
  if (!hasAccess) return { output: blocked(meetingId, oppId, "AccessDenied",
    "You do not have access to this opportunity. No data has been shown.") };
  log.add("system", "opportunity_read", oppId, "ok", `stage=${opp.fields.stage.value}`);

  const tPath = path.join(KIT, meeting.transcript_file || "");
  if (!meeting.transcript_file || !fs.existsSync(tPath)) {
    log.add("system", "transcript_checked", meetingId, "blocked", "missing");
    return { output: blocked(meetingId, oppId, "Missing", "No Teams transcript is available for this meeting. Update the CRM manually.") };
  }
  const transcript = fs.readFileSync(tPath, "utf8");
  const stamps = [...transcript.matchAll(/^\[(\d{2}:\d{2}:\d{2})\]/gm)].map((m) => tsToSec(m[1]));
  const lastSec = stamps.length ? Math.max(...stamps) : 0;
  const coverage = lastSec / (meeting.actual_duration_minutes * 60);
  const incomplete = meeting.transcript_status !== "complete" || /\[Transcript ended/i.test(transcript) || coverage < 0.6;
  log.add("system", "transcript_checked", meetingId, incomplete ? "blocked" : "ok",
    `status=${meeting.transcript_status}; coverage=${Math.round(coverage * 100)}%`);
  if (incomplete) return { output: blocked(meetingId, oppId, "Incomplete",
    `The transcript is incomplete (status: ${meeting.transcript_status}; covers ${Math.round(coverage * 100)}% of the meeting). No update will be proposed; complete the record manually.`) };

  return { meeting, opp, user, transcript };
}

// ------------------------------------------------------------------ 2. prompt
export function buildPrompt({ meeting, opp, transcript, data }) {
  let system = rd("agent/system_prompt.md").split("\n---\n\n## User message template")[0];
  system = system.replace(/^> At runtime.*\n/m, "");
  for (const f of ["policies/agent_policy.md", "policies/field_dictionary.md", "policies/stage_rules.md"])
    system = system.replace(`{{${f}}}`, rd(f));
  const ex = ["EX1", "EX2"].map((x) =>
    `### Example ${x}\nCONTEXT\n${rd(`examples/${x}_context.json`)}\nTRANSCRIPT\n${rd(`examples/${x}_transcript.txt`)}\nEXPECTED OUTPUT\n${rd(`examples/${x}_expected_output.json`)}`).join("\n\n");
  system = system.replace(/\{\{examples\/EX1_\*[^}]*\}\}/, ex);

  const { transcript_file, ...meetingMeta } = meeting;
  const roster = data.team.map((u) => `- ${u.name} (${u.role})`).join("\n");
  const user = `MEETING\n${JSON.stringify(meetingMeta, null, 2)}\n\nOPPORTUNITY (current CRM values; "approved": true = approved by the seller)\n${JSON.stringify(opp, null, 2)}\n\nTEAM ROSTER (allowed follow-up owners)\n${roster}\n\nTRANSCRIPT\n${transcript}`;
  return { system, user };
}

// ------------------------------------------------------------------ 3. model call
export async function callModel({ system, user }, model = DEFAULT_MODEL) {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) throw new Error("ANTHROPIC_API_KEY is not set");
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({ model, max_tokens: 4000, system, messages: [{ role: "user", content: user }] }),
  });
  if (!res.ok) throw new Error(`API ${res.status}: ${await res.text()}`);
  const body = await res.json();
  const text = body.content.filter((c) => c.type === "text").map((c) => c.text).join("");
  const json = text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1);
  return JSON.parse(json);
}

// ------------------------------------------------------------------ 4. validator (guardrails applied in code, not trusted to the model)
const norm = (s) => (s || "").toLowerCase().replace(/[‘’]/g, "'").replace(/[“”]/g, '"').replace(/\s+/g, " ").trim();
export function transcriptLines(transcript) {
  return transcript.split("\n").map((l) => l.match(/^\[(\d{2}:\d{2}:\d{2})\] ([^:]+): (.*)$/)).filter(Boolean)
    .map((m) => ({ timestamp: m[1], speaker: m[2], text: norm(m[3]) }));
}
export const quoteFound = (lines, q) => !!q && norm(q).length > 3 && lines.some((l) => l.text.includes(norm(q)));

export function validateOutput(raw, { meeting, opp, transcript, data }) {
  const notes = [];
  const lines = transcriptLines(transcript);
  const roster = data.team.map((u) => u.name);
  if (raw.run_status === "Blocked") {
    return { ...blocked(meeting.meeting_id, opp.opportunity_id, raw.source_status || "Unmatched", raw.block_reason || "Blocked by agent."), validation_notes: notes };
  }
  const byField = Object.fromEntries((raw.fields || []).map((f) => [f.field, f]));
  const fields = FIELDS.map((name) => {
    const cur = opp.fields[name];
    let f = byField[name] || { field: name, status: "no_evidence", evidence: [], note: "Missing in model output." };
    f = { field: name, current_value: cur.value, current_approved: cur.approved, status: f.status, proposed_value: f.proposed_value ?? null,
          evidence: Array.isArray(f.evidence) ? f.evidence.slice(0, 3) : [], note: f.note ?? null };
    const downgrade = (why) => { notes.push(`${name}: ${why} -> no_evidence`); f.status = "no_evidence"; f.proposed_value = null; f.evidence = []; f.note = `Validator: ${why}`; };

    if (!["proposed", "no_evidence", "contradictory"].includes(f.status)) downgrade(`invalid status '${f.status}'`);
    if (f.status !== "no_evidence") {
      const good = f.evidence.filter((e) => quoteFound(lines, e.quote));
      if (good.length < f.evidence.length) notes.push(`${name}: removed ${f.evidence.length - good.length} quote(s) not found in transcript`);
      f.evidence = good;
      if (!good.length) downgrade("no evidence quote found verbatim in the transcript");
    }
    if (f.status === "contradictory" && !(STATE_FIELDS.includes(name) && cur.approved && cur.value))
      downgrade("contradictory is only allowed on a seller-approved state field");
    if (f.status === "contradictory") f.proposed_value = null;
    if (f.status === "no_evidence") f.proposed_value = null;
    if (f.status === "proposed") {
      if (!f.proposed_value) downgrade("proposed without a value");
      else if (name === "follow_up_owner" && !roster.includes(f.proposed_value)) downgrade(`owner '${f.proposed_value}' is not in the team roster`);
      else if (name === "follow_up_due_date" && !/^\d{4}-\d{2}-\d{2}$/.test(f.proposed_value)) downgrade(`date '${f.proposed_value}' is not YYYY-MM-DD`);
      else if (name === "stage") {
        const from = STAGES.indexOf(cur.value), to = STAGES.indexOf(f.proposed_value);
        if (to < 0) downgrade(`unknown stage '${f.proposed_value}'`);
        else if (f.proposed_value.startsWith("Closed")) downgrade("Closed Won/Lost can only be set by the seller");
        else if (to !== from + 1) downgrade(`stage move ${cur.value} -> ${f.proposed_value} is not one step forward`);
      }
    }
    return f;
  });
  const extra = (raw.fields || []).filter((f) => !FIELDS.includes(f.field));
  if (extra.length) notes.push(`dropped out-of-scope fields: ${extra.map((f) => f.field).join(", ")}`);
  return { meeting_id: meeting.meeting_id, opportunity_id: opp.opportunity_id, source_status: "Ready", run_status: "Awaiting review",
           block_reason: null, fields, ignored_out_of_scope: raw.ignored_out_of_scope || [], validation_notes: notes };
}

// ------------------------------------------------------------------ 5. write after seller review (platform only)
// decisions: { field: { decision: "approve"|"edit"|"reject"|"keep"|"replace"|"clear", value?: string, reason?: string } }
export function applyApprovedFields({ output, decisions, crm, reviewerId, log }) {
  const opp = crm.find((o) => o.opportunity_id === output.opportunity_id);
  const actionable = output.fields.filter((f) => f.status !== "no_evidence");
  const missing = actionable.filter((f) => !decisions[f.field]);
  if (missing.length) throw new Error(`Decision required for: ${missing.map((f) => f.field).join(", ")}`);
  const record = [];
  for (const f of actionable) {
    const d = decisions[f.field];
    let final = null, write = false;
    if (f.status === "proposed" && d.decision === "approve") { final = f.proposed_value; write = true; }
    else if (f.status === "proposed" && d.decision === "edit") { final = d.value; write = true; }
    else if (f.status === "contradictory" && d.decision === "replace") { final = d.value; write = true; }
    else if (f.status === "contradictory" && d.decision === "clear") { final = null; write = true; }
    else if (f.status === "contradictory" && d.decision === "keep") { final = f.current_value; }
    log.add(reviewerId, "field_decided", `${output.opportunity_id}.${f.field}`, "ok", d.decision);
    let result = "Not written";
    if (write) {
      log.add("system", "crm_write_attempted", `${output.opportunity_id}.${f.field}`, "ok");
      opp.fields[f.field] = { value: final, approved: true };
      result = "Succeeded";
      log.add("system", "crm_write_result", `${output.opportunity_id}.${f.field}`, "ok", result);
    }
    record.push({ field: f.field, previous_value: f.current_value, agent_status: f.status, agent_proposal: f.proposed_value, evidence: f.evidence,
      seller_decision: d.decision, final_value: final, rejection_reason: d.reason ?? null, reviewer_id: reviewerId,
      decided_at: new Date().toISOString(), write_result: result });
  }
  return record;
}

// ------------------------------------------------------------------ mock model (reference answers; never put these in the prompt)
function mockOutput(meetingId) {
  const dir = path.join(KIT, "eval/reference_outputs");
  for (const f of fs.readdirSync(dir)) {
    const o = JSON.parse(fs.readFileSync(path.join(dir, f), "utf8"));
    if (o.meeting_id === meetingId && o.run_status !== "Blocked") return o;
  }
  throw new Error(`No reference output for ${meetingId}`);
}

// ------------------------------------------------------------------ orchestration
export async function runAgent({ meetingId, opportunityId, userId, dryRun = false, mock = false, crm }) {
  const data = loadData(crm);
  const runId = `RUN-${Date.now()}`;
  const log = newLog(runId);
  const pre = prepareRun({ meetingId, opportunityId, userId, data, log });
  if (pre.output) { log.add("system", "run_blocked", meetingId, "blocked", pre.output.block_reason); return { output: pre.output, log: log.events }; }
  const prompt = buildPrompt({ ...pre, data });
  if (dryRun) return { output: { dry_run: true, system_chars: prompt.system.length, user_preview: prompt.user.slice(0, 400) }, log: log.events };
  log.add("system", "agent_called", meetingId, "ok", mock ? "MOCK (reference output)" : DEFAULT_MODEL);
  const raw = mock ? mockOutput(meetingId) : await callModel(prompt);
  const output = validateOutput(raw, { ...pre, data });
  log.add("system", "output_validated", meetingId, "ok", `${output.validation_notes.length} correction(s)`);
  log.add("agent", "proposals_generated", pre.opp.opportunity_id, "ok",
    output.fields.map((f) => `${f.field}=${f.status}`).join(", "));
  return { output, log: log.events };
}

// ------------------------------------------------------------------ CLI
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  const arg = (k) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : undefined; };
  const dryRun = args.includes("--dry-run");
  const mock = args.includes("--mock");
  const cases = rj("eval/expected_results.json").cases;
  const jobs = args.includes("--all") ? cases : arg("--case") ? cases.filter((c) => c.case_id === arg("--case")) : [];
  if (arg("--meeting")) jobs.push({ case_id: arg("--meeting"), meeting_id: arg("--meeting"), opportunity_id: undefined, run_as_user_id: arg("--user") || "U01" });
  if (!jobs.length) { console.log("Usage: --case T1 | --all | --meeting MTG-1001 --user U01  [--dry-run]"); process.exit(1); }
  const outDir = path.join(KIT, "eval/outputs"); fs.mkdirSync(outDir, { recursive: true });
  for (const c of jobs) {
    try {
      const { output, log } = await runAgent({ meetingId: c.meeting_id, opportunityId: c.opportunity_id, userId: c.run_as_user_id, dryRun, mock });
      if (!dryRun) {
        fs.writeFileSync(path.join(outDir, `${c.case_id}.json`), JSON.stringify(output, null, 2));
        fs.writeFileSync(path.join(outDir, `${c.case_id}.log.json`), JSON.stringify(log, null, 2));
      }
      const summary = output.run_status === "Blocked" ? `Blocked (${output.source_status})`
        : output.dry_run ? "Ready -> would call model" : output.fields.map((f) => `${f.field}:${f.status}`).join(" ");
      console.log(`${c.case_id}  ${summary}`);
    } catch (e) { console.error(`${c.case_id}  ERROR ${e.message}`); }
  }
}
