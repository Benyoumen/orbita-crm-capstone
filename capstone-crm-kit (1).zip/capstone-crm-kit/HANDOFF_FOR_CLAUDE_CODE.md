# Handoff: wire the Call-to-CRM Agent into the existing Sales CRM mockup

> Paste this into Claude Code from the root of the mockup project, after copying the `capstone-crm-kit/` folder into it.

## Goal
Make the mockup demonstrate **one end-to-end loop**: a Teams sales-call transcript → the agent proposes updates to 8 CRM fields with transcript evidence → the seller approves, edits, or rejects each field → only approved values are written to the CRM → every step is logged. It must handle the edge cases: no evidence, contradiction, blocked source, stage boundary, and access denied.

Out of scope (do not build): pre-meeting briefings, solution recommendation, proposals and pricing, SharePoint, manager dashboards.

## First, inspect before changing anything
1. Read the existing mockup: stack, data layer, routing, and the existing CRM/opportunity screens. Reuse them. Do not rebuild the app.
2. Read everything in `capstone-crm-kit/`, starting with `README.md`, `agent/pipeline.mjs`, `agent/output_schema.json`, and `policies/`.
3. Propose a short plan (files to add or change) and wait for confirmation if the change touches more than the CRM views and a new review page.

## What already exists in the kit (use it, don't rewrite it)
- `agent/pipeline.mjs`: pre-checks (match, access, transcript completeness), prompt building, model call, **validator** (guardrails in code), and `applyApprovedFields` (the only write path). Import it server-side.
- `data/*.json`: CRM seed (6 opportunities), team and access, 8 Teams meetings. `transcripts/`: 8 test transcripts.
- `eval/expected_results.json` + `eval/run_eval.mjs`: the test set and scorer. `eval/reference_outputs/`: correct answers, used by `--mock`.

## Build steps
1. **CRM store**: seed the mockup's opportunity data from `data/opportunities.json`. Each of the 8 fields is `{ value, approved }`. Keep amount, close date, and contacts visible but read-only for the agent. Add a "Reset demo data" action that restores the seed (needed before each eval case).
2. **Server endpoint** (the API key must never reach the browser). If the mockup is frontend-only, add a minimal Node server or API route.
   - `POST /api/runs` `{ meetingId, userId, mock? }` → `runAgent()` from the pipeline (pass the current CRM state as `crm`) → returns `{ output, log }`. Persist the run (in memory or a JSON file is fine).
   - `POST /api/runs/:id/submit` `{ decisions }` → `applyApprovedFields()` → updates the CRM store and returns the per-field write record. Reject the request if any proposed or contradictory field has no decision.
   - `GET /api/runs/:id` → output + decisions + log.
3. **Meetings list ("Recent Teams calls")**: show `data/meetings.json` for the current user, with a "Prepare CRM update" button. Add a simple user switcher (U01 Ana Ribeiro by default, U02, U04) so the access case can be demoed.
4. **Review page** (see PRD F25):
   - Header: opportunity, account, seller, current stage, meeting date, source status, run status.
   - Table, one row per field: field | current value (✓ if seller-approved) | proposed value | evidence (quote + timestamp; clicking it shows the transcript line highlighted, as a stand-in for "open in Teams") | decision.
   - `proposed` → Approve / Edit (inline text) / Reject (optional reason). `contradictory` → Keep / Replace / Clear, with the contradicting quote shown. `no_evidence` → grey "No evidence", no controls.
   - Show the stage note (missing criteria), `ignored_out_of_scope` ("Ignored: amount mentioned on call") and `validation_notes`.
   - Submit is disabled until every actionable row has a decision. After Submit, show Succeeded/Failed per field and the updated CRM record.
   - **Blocked** runs: no table and no Submit, just the reason. For AccessDenied, show no opportunity data at all.
5. **Audit log view**: for a run, list the events in order (timestamp, actor, action, object, outcome) and the field decisions (previous value, agent proposal, seller decision, final value).
6. **Mock / live toggle**: `mock: true` uses the reference outputs (no API key). Live uses `ANTHROPIC_API_KEY` and `CLAUDE_MODEL`. The UI must label which mode is active.
7. **Eval**: keep `node capstone-crm-kit/agent/pipeline.mjs --all` + `node capstone-crm-kit/eval/run_eval.mjs` working (live mode) and check the outputs into `eval/outputs/`. Optionally add an "Eval" page that shows `eval/results.md`.

## Hard rules (do not break them for convenience)
- Nothing writes to the CRM except `applyApprovedFields`, and only after Submit.
- Never pass `eval/reference_outputs/` or `eval/expected_results.json` into the model prompt.
- The validator runs on every live output. Never show raw model output to the seller.
- Transcripts are not copied into the run log, only referenced.

## Acceptance criteria (all must pass)
| # | Do this | Expect |
|---|---|---|
| 1 | Ana runs MTG-1001 (Acme) | 8 proposals with quotes; stage Qualified → Solution; due 2026-11-06; nothing written before Submit |
| 2 | Ana runs MTG-1002 (Verde) | Follow-up due date = No evidence; stage = No evidence |
| 3 | Ana runs MTG-1003 (Nimbus) | Next step + due date = Contradictory with Keep/Replace/Clear; other fields still reviewable |
| 4 | Ana runs MTG-1004 / MTG-1005 | Blocked: Incomplete / Unmatched; no proposals, no Submit |
| 5 | Ana runs MTG-1006 (Atlas) | No stage change (note names the CFO criterion); amount listed as ignored; never Closed Won |
| 6 | Ana runs MTG-1007, edits customer need, approves the rest | CRM shows her edited text; the audit keeps both versions, her ID, and the time |
| 7 | Ana runs MTG-1008 (Lucas's opportunity) | Blocked: AccessDenied; no opportunity data shown; attempt logged |
| 8 | Live eval: `pipeline.mjs --all` then `run_eval.mjs` | `eval/results.md` produced (target 8/8; record any failures honestly for PRD F33) |

## Demo script (PRD F18, ~90 seconds of the video)
Reset data → Ana opens "Recent Teams calls" → MTG-1001 → review page → approve 6, edit customer need, reject 1 → Submit → CRM record updated + audit log. Then MTG-1003 (contradiction, choose Keep), then MTG-1004 (Blocked).
