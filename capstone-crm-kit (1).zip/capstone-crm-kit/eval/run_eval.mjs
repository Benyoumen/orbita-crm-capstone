// Scores agent outputs against eval/expected_results.json.
//   node eval/run_eval.mjs                 reads eval/outputs/<case_id>.json
//   node eval/run_eval.mjs path/to/outputs
// Writes eval/results.md (paste the table into PRD row F33).

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const KIT = path.resolve(HERE, "..");
const outDir = path.resolve(process.argv[2] || path.join(HERE, "outputs"));
const expected = JSON.parse(fs.readFileSync(path.join(HERE, "expected_results.json"), "utf8")).cases;
const meetings = JSON.parse(fs.readFileSync(path.join(KIT, "data/meetings.json"), "utf8"));
const roster = JSON.parse(fs.readFileSync(path.join(KIT, "data/team.json"), "utf8")).map((u) => u.name);
const FIELDS = ["call_summary", "customer_need", "objection", "commitment", "next_step", "follow_up_owner", "follow_up_due_date", "stage"];

const norm = (s) => (s || "").toLowerCase().replace(/[‘’]/g, "'").replace(/[“”]/g, '"').replace(/\s+/g, " ").trim();
const groupsOk = (text, groups) => (groups || []).every((g) => g.some((k) => norm(text).includes(norm(k))));

const rows = [];
let passed = 0;
for (const c of expected) {
  const fails = [];
  const file = path.join(outDir, `${c.case_id}.json`);
  if (!fs.existsSync(file)) { rows.push({ c, verdict: "NO OUTPUT", fails: [`missing ${path.relative(KIT, file)}`] }); continue; }
  const out = JSON.parse(fs.readFileSync(file, "utf8"));
  const meeting = meetings.find((m) => m.meeting_id === c.meeting_id);
  const tPath = path.join(KIT, meeting.transcript_file);
  const lines = fs.existsSync(tPath) ? fs.readFileSync(tPath, "utf8").split("\n").map((l) => norm(l.replace(/^\[[^\]]+\] [^:]+: /, ""))) : [];

  if (out.run_status !== c.expected_run_status) fails.push(`run_status ${out.run_status} != ${c.expected_run_status}`);
  if (out.source_status !== c.expected_source_status) fails.push(`source_status ${out.source_status} != ${c.expected_source_status}`);

  if (c.expected_run_status === "Blocked") {
    if ((out.fields || []).length) fails.push("Blocked run must contain no field proposals");
    if (!out.block_reason) fails.push("Blocked run must give a block_reason");
  } else {
    const got = Object.fromEntries((out.fields || []).map((f) => [f.field, f]));
    const extra = (out.fields || []).filter((f) => !FIELDS.includes(f.field));
    if (extra.length) fails.push(`out-of-scope fields present: ${extra.map((f) => f.field).join(", ")}`);
    for (const name of FIELDS) {
      const exp = c.fields[name]; const f = got[name];
      if (!f) { fails.push(`${name}: missing`); continue; }
      const okStatuses = exp.status_any || [exp.status];
      if (!okStatuses.includes(f.status)) { fails.push(`${name}: status ${f.status}, expected ${okStatuses.join("/")}`); continue; }
      if (f.status !== "proposed" && f.proposed_value) fails.push(`${name}: has a value although status is ${f.status}`);
      if (f.status !== "no_evidence") {
        if (!f.evidence?.length) fails.push(`${name}: no evidence`);
        for (const e of f.evidence || []) if (!lines.some((l) => l.includes(norm(e.quote)))) fails.push(`${name}: quote not in transcript ("${(e.quote || "").slice(0, 40)}...")`);
      }
      if (f.status === "proposed") {
        if (exp.value && norm(f.proposed_value) !== norm(exp.value)) fails.push(`${name}: '${f.proposed_value}' != '${exp.value}'`);
        if (exp.must_include && !groupsOk(f.proposed_value, exp.must_include)) fails.push(`${name}: missing key facts ${JSON.stringify(exp.must_include)}`);
        if (name === "follow_up_owner" && !roster.includes(f.proposed_value)) fails.push(`${name}: not in roster`);
      }
      if (exp.note_must_include && !groupsOk(f.note, exp.note_must_include)) fails.push(`${name}: note should name missing criteria ${JSON.stringify(exp.note_must_include)}`);
    }
    if (c.forbidden_stage_values && got.stage?.status === "proposed" && c.forbidden_stage_values.includes(got.stage.proposed_value))
      fails.push(`stage: forbidden value ${got.stage.proposed_value}`);
    if (c.expect_out_of_scope_ignored && !(out.ignored_out_of_scope || []).length) fails.push("out-of-scope request (amount) not listed in ignored_out_of_scope");
  }
  const verdict = fails.length ? "FAIL" : "PASS";
  if (!fails.length) passed++;
  rows.push({ c, verdict, fails });
}

const manual = expected.filter((c) => c.platform_checks);
let md = `# Eval results\n\nRun: ${new Date().toISOString()}  \nOutputs: ${path.relative(KIT, outDir)}\n\n**${passed}/${expected.length} automated cases passed**\n\n| Case | PRD case | Scenario | Result | Issues |\n|---|---|---|---|---|\n`;
for (const r of rows) md += `| ${r.c.case_id} | ${r.c.prd_case} | ${r.c.name} | ${r.verdict} | ${r.fails.join("; ").replace(/\|/g, "/") || "-"} |\n`;
md += `\n## Manual platform checks (verify in the app, tick when done)\n`;
for (const c of manual) { md += `\n**${c.case_id}: ${c.name}**\n`; for (const p of c.platform_checks) md += `- [ ] ${p}\n`; if (c.review_script) md += `- Review script: ${JSON.stringify(c.review_script)}\n`; }
fs.writeFileSync(path.join(HERE, "results.md"), md);

for (const r of rows) console.log(`${r.c.case_id.padEnd(4)} ${r.verdict.padEnd(9)} ${r.c.name}${r.fails.length ? "\n       - " + r.fails.join("\n       - ") : ""}`);
console.log(`\n${passed}/${expected.length} passed. Details: eval/results.md`);
